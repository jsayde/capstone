package com.example.capstone;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class AdminLogin extends AppCompatActivity {

    private EditText etUsrAdmin, etPasAdmin;
    private Button btnLog, btBack;
    private FirebaseAuth fbAdminAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_login);
        etPasAdmin = (EditText)findViewById(R.id.etPassAdmin);
        etUsrAdmin = (EditText)findViewById(R.id.etUserAdmin);
        btnLog = (Button)findViewById(R.id.btnLogin);
        btBack = (Button)findViewById(R.id.btnBack);
        fbAdminAuth = FirebaseAuth.getInstance();
        btBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(AdminLogin.this, Basic.class));
            }
        });

        btnLog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String user_email = etUsrAdmin.getText().toString().trim();
                String user_pass = etPasAdmin.getText().toString().trim();
                fbAdminAuth.signInWithEmailAndPassword(user_email,user_pass).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()){
                            Toast.makeText(AdminLogin.this,"Login Successful",Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(AdminLogin.this,AdminPage.class));
                        }
                        else{
                            Toast.makeText(AdminLogin.this,"Login Failed",Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }
        });
    }
}
