package com.example.capstone;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class Register extends AppCompatActivity {

    private EditText userName, userEmail, userPhone, userPass1, userPass2;
    private Button regButton, logButton;
    private FirebaseAuth fbAuth;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        userName = (EditText)findViewById(R.id.etFullName);
        userEmail = (EditText)findViewById(R.id.etUserEmail);
        userPhone = (EditText)findViewById(R.id.etPhone);
        userPass1 = (EditText)findViewById(R.id.etPass1);
        userPass2 = (EditText)findViewById(R.id.etPass2);
        regButton = (Button)findViewById(R.id.btReg);
        logButton = (Button)findViewById(R.id.btLogin);

        fbAuth = FirebaseAuth.getInstance();
        regButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(validation()){
                    String user_email = userEmail.getText().toString().trim();
                    String user_pass = userPass1.getText().toString().trim();
                    fbAuth.createUserWithEmailAndPassword(user_email, user_pass).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()){
                                Toast.makeText(Register.this,"Registration Successful", Toast.LENGTH_SHORT).show();
                                startActivity(new Intent(Register.this, MainActivity.class));
                            }
                            else{
                                Toast.makeText(Register.this, "Registration Failed", Toast.LENGTH_SHORT).show();
                            }
                        }
                    });

                }
            }
        });

        logButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Register.this,MainActivity.class));
            }
        });
    }
    private Boolean validation(){
        Boolean result = false;

        String name = userName.getText().toString();
        String password1 = userPass1.getText().toString();
        String password2 = userPass2.getText().toString();
        String email = userEmail.getText().toString();
        String phone = userPhone.getText().toString();

        if (name.isEmpty() || password1.isEmpty() || password2.isEmpty() || email.isEmpty() || phone.isEmpty()) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
        }
        else if (!(password1.contentEquals(password2))){
            Toast.makeText(this, "Password's do not match. Please re-enter", Toast.LENGTH_SHORT).show();
        }
        else if (password1.length() < 6)
            Toast.makeText(this, "Password must be 6 characters or longer", Toast.LENGTH_SHORT).show();
        else {
            result = true;
        }
        return result;
    }

}
