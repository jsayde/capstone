package com.example.capstone;

import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;

public class Basic extends AppCompatActivity {

    private TextView displayBar;
    private SensorManager sensorManager;
    private Sensor pressureSensor;
    private Button btLout, btAdm;
    private FirebaseAuth firebAuth;
    private SensorEventListener sensorEventListener = new SensorEventListener() {
        @Override
        public void onSensorChanged(SensorEvent event) {
            float[] values = event.values;
            displayBar.setText(String.format("%.3f mbar", values[0]));
        }

        @Override
        public void onAccuracyChanged(Sensor sensor, int accuracy) {

        }
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_basic);
        displayBar = (TextView)findViewById(R.id.tvAltdis);

        firebAuth = FirebaseAuth.getInstance();
        btLout = (Button)findViewById(R.id.btLogout);
        btAdm = (Button)findViewById(R.id.btAdmin);
        sensorManager = (SensorManager)getSystemService(SENSOR_SERVICE);
        pressureSensor = sensorManager.getDefaultSensor(Sensor.TYPE_PRESSURE);

        btAdm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Basic.this,AdminLogin.class));
            }
        });
        btLout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                firebAuth.signOut();
                finish();
                startActivity(new Intent(Basic.this,MainActivity.class));
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        sensorManager.registerListener(sensorEventListener, pressureSensor, SensorManager.SENSOR_DELAY_UI);
    }

    @Override
    protected void onPause() {
        super.onPause();
        sensorManager.unregisterListener(sensorEventListener);
    }
}
